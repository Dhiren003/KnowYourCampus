<?php

require_once 'DB_Functions.php';
$db = new DB_Functions();

$response = array("error" => FALSE);

if(isset($_GET['en_no']) && isset($_GET['email'])){
    $en_no = $_GET['en_no'];
    $email = $_GET['email'];
    $contact_no = $_GET['contact_no'];
    $feedback = $_GET['feedback'];

    $user = $db->storeFeedback($en_no, $contact_no, $email, $feedback);
    if ($user) {
        echo "Done";
    } else {
        echo "Failed";
    }
} else {
    echo "MisMatch";
}
?>

