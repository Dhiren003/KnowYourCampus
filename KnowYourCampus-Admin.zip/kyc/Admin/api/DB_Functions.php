<?php

class DB_Functions {

    private $conn;

    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }

    public function storeUser($en_no, $name, $email, $password, $department, $contact_no, $gender) {

        $stmt = $this->conn->prepare("INSERT INTO tbl_student(en_no, name, email, password, department, contact_no, gender) VALUES(?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $en_no, $name, $email, $password, $department, $contact_no, $gender);
        $result = $stmt->execute();
        $stmt->close();

        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM tbl_student WHERE en_no = ?");
            $stmt->bind_param("s", $en_no);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return $user;
        } else {
            return false;
        }
    }

    public function getUser($en_no, $password) {
        $stmt = $this->conn->prepare("SELECT * FROM tbl_student WHERE en_no = ?");

        $stmt->bind_param("s", $en_no);

        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            // check for password equality
            if ($password == $user['password']) {
                // user authentication details are correct
                return $user;
            }
            return NULL;
        } else {
            return NULL;
        }
    }

    public function isUserExisted($en_no) {
        $stmt = $this->conn->prepare("SELECT en_no from tbl_student WHERE en_no = ?");

        $stmt->bind_param("s", $en_no);

        $stmt->execute();

        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }

    /////
    ///
    ///

    public function storeFact($fac_id, $name, $email, $password, $department, $contact_no, $gender) {

        $stmt = $this->conn->prepare("INSERT INTO tbl_faculty(fac_id, name, email, password, dept_id, contact_no, gender, is_head) VALUES(?, ?, ?, ?, ?, ?, ?, 0)");
        $stmt->bind_param("sssssss", $fac_id, $name, $email, $password, $department, $contact_no, $gender);
        $result = $stmt->execute();
        $stmt->close();

        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM tbl_faculty WHERE fac_id = ?");
            $stmt->bind_param("s", $fac_id);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return $user;
        } else {
            return false;
        }
    }

    public function getFact($fac_id, $password) {
        $stmt = $this->conn->prepare("SELECT * FROM tbl_faculty WHERE fac_id = ?");

        $stmt->bind_param("s", $fac_id);

        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            // check for password equality
            if ($password == $user['password']) {
                // user authentication details are correct
                return $user;
            }
            return NULL;
        } else {
            return NULL;
        }
    }

    public function isFactExisted($fac_id) {
        $stmt = $this->conn->prepare("SELECT fac_id from tbl_faculty WHERE fac_id = ?");

        $stmt->bind_param("s", $fac_id);

        $stmt->execute();

        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // user existed
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }

    ///
    /// //
    ///

    public function storeFeedback($en_no, $contact_no, $email, $feedback) {

        $stmt = $this->conn->prepare("INSERT INTO tbl_feedback(en_no, contact_no, email, feedback, feed_date_time) VALUES(?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssss", $en_no, $contact_no, $email, $feedback);
        $result = $stmt->execute();
        $stmt->close();

        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM tbl_feedback WHERE en_no = ?");
            $stmt->bind_param("s", $en_no);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return $user;
        } else {
            return false;
        }
    }
}
?>
