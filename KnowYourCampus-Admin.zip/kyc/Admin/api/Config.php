<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "kyc");
define('FIREBASE_API_KEY', 'AAAAExPTvSE:APA91bFEhRCtM1n7YYVBWMybYl0kczgxbo-CnqI7aDw2TS2biLjxjE7p-7zRwToYfL7M6XtLnaM3-eqXeBTY1xQOisrM_eSqJ9uuUlDl_S3PAPCZPMWeGxSsY4HoShHMy9wVBvzWlcNU');
?>
