<?php

require_once 'DB_Functions.php';
$db = new DB_Functions();

$response = array("error" => FALSE);

if (isset($_GET['is_fact']) && isset($_GET['password'])) {

    if($_GET['is_fact'] == 1 && isset($_GET['fac_id'])){
        // receiving the post params
        $fac_id = $_GET['fac_id'];
        $password = $_GET['password'];

        // get the user by email and password
        $user = $db->getFact($fac_id, $password);

        if ($user != false) {
            // use is found
            echo $user['name'];
        } else {
            echo "Fail";
        }
    } else if ($_GET['is_fact'] != 1 && isset($_GET['en_no'])) {
        // receiving the post params
        $en_no = $_GET['en_no'];
        $password = $_GET['password'];

        // get the user by email and password
        $user = $db->getUser($en_no, $password);

        if ($user != false) {
            echo $user['name'];
        } else {
            echo "Failed";
        }
    } else {
        echo "MisMatch";
    }
} else {
    echo "Wrong Args";
}
?>

