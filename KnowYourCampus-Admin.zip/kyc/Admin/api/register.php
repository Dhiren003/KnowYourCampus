<?php

require_once 'DB_Functions.php';
$db = new DB_Functions();

$response = array("error" => FALSE);

if (isset($_GET['is_fact']) && isset($_GET['name']) && isset($_GET['email'])) {

    if($_GET['is_fact'] == 1 && isset($_GET['fac_id'])){
        $en_no = $_GET['fac_id'];
        $name = $_GET['name'];
        $email = $_GET['email'];
        $password = $_GET['password'];
        $department = $_GET['dept_id'];
        $contact_no = $_GET['contact_no'];
        $gender = $_GET['gender'];

        // check if user is already existed with the same email
        if ($db->isFactExisted($en_no)) {
            echo "Already";
        } else {
            // create a new user
            $user = $db->storeFact($en_no, $name, $email, $password, $department, $contact_no, $gender);
            if ($user) {
                echo "Done";
            } else {
                echo "Failed";
            }
        }
    } else if ($_GET['is_fact'] != 1 && isset($_GET['en_no'])) {
        $en_no = $_GET['en_no'];
        $name = $_GET['name'];
        $email = $_GET['email'];
        $password = $_GET['password'];
        $department = $_GET['dept'];
        $contact_no = $_GET['contact_no'];
        $gender = $_GET['gender'];

        // check if user is already existed with the same email
        if ($db->isUserExisted($en_no)) {
            echo "Already";
        } else {
            // create a new user
            $user = $db->storeUser($en_no, $name, $email, $password, $department, $contact_no, $gender);
            if ($user) {
                echo "Done";
            } else {
                echo "Failed";
            }
        }
    } else {
        echo "MisMatch";
    }
} else {
    echo "Wrong Args";
}
?>

