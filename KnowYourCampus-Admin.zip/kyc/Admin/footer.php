  <footer class="page-footer" style="background-color: #FF0000">
    <div class="footer-copyright">
      <div class="container">
        <span>Copyright &copy; 2018 <a class="grey-text text-lighten-4" href="#" target="_blank"> KnowYourCampus </a> All rights reserved.</span>
        <span class="right"> Design and Developed by <a class="grey-text text-lighten-4" href="#">KnowYourCampus</a></span>
        </div>
    </div>
  </footer>